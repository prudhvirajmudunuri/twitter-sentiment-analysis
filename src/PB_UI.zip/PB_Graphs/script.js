$(function () {
    $('#container').highcharts({
        chart: {
            type: 'pie',
            options3d: {
                enabled: true,
                alpha: 45,
                beta: 0
            }
        },
        title: {
            text: 'Graph 1'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                depth: 35,
                dataLabels: {
                    enabled: true,
                    format: '{point.name}'
                }
            }
        },
        series: [{
            type: 'pie',
            name: '# of Tweets',
            data: [
                ['United States',   3395],
                ['United Kingdom',   280],
                ['Canada', 155],
                ['España',  122],
                ['Brasil',   112],
                ['France',   65],
                ['Columbia', 65],
                ['Mexico', 46],
                ['Italia', 38],
                ['South Africa', 30]
            ]
        }]
    });
});